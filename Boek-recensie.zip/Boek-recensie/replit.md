# replit.md

## Overview

BoekDeel ("BookShare") is a Dutch-language web application where users can share their reading experiences. Users can upload book files, write reviews, and leave comments on each other's book entries. The app stores books in memory (no persistent database) and saves uploaded files to a local `uploads/` directory.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Backend
- **Framework**: Flask (Python) — a lightweight web framework serving both HTML pages and handling form submissions.
- **Data Storage**: In-memory Python list (`books`). There is no database; all data is lost on server restart. Each book entry contains an ID (UUID), title, filename, review text, and a list of comments.
- **File Uploads**: Uploaded files are saved to an `uploads/` directory using Werkzeug's `secure_filename`. Each file is prefixed with a UUID to prevent filename collisions.
- **Entry Point**: The main application logic is in `app.py`. The `main.py` file exists but is currently empty — it should import and run the Flask app.

### Frontend
- **Templating**: Jinja2 templates served by Flask, located in the `templates/` directory.
- **Styling**: Inline CSS within the HTML template (no separate CSS framework or file). Uses CSS custom properties and a clean, modern design.
- **Language**: The UI is in Dutch.

### Routes
| Route | Method | Purpose |
|-------|--------|---------|
| `/` | GET | Display all books with reviews |
| `/` | POST | Upload a new book with title, review, and file |
| `/comment/<book_id>` | POST | Add a comment to a specific book |

### Key Architectural Decisions
1. **In-memory storage instead of a database**: Chosen for simplicity. The major downside is data loss on restart. If persistence is needed, a database (e.g., SQLite or PostgreSQL with an ORM like Drizzle or SQLAlchemy) should be added.
2. **Monolithic Flask app**: Everything lives in a single `app.py` file. For a small project this is fine, but as features grow, it should be refactored into blueprints or separate modules.
3. **File-based uploads**: Files are stored directly on disk rather than in cloud storage. This works for local development but won't scale well in production or on ephemeral file systems.

### Important Notes
- The `app.py` file's `add_comment` route appears to be truncated/incomplete — the function body is cut off. It needs to be completed to properly append comments to the matching book entry and redirect back.
- `main.py` is empty and should be set up to run the Flask app (e.g., `from app import app; app.run(host='0.0.0.0', port=5000)`).
- The `index.html` template is also truncated and needs to be completed with the full form and book listing markup.

## External Dependencies

- **Flask**: Web framework (Python)
- **Werkzeug**: Bundled with Flask, used for secure filename handling
- **No external database**: Data is stored in memory
- **No third-party APIs or services**: The application is entirely self-contained
- **Python standard library**: `os`, `uuid` for file management and unique ID generation