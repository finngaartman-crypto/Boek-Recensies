from flask import Flask, render_template, request, redirect, url_for, send_from_directory
import os
import uuid
from werkzeug.utils import secure_filename

app = Flask(__name__)

# Map voor uploads
UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

# Iets uitgebreidere "database" in geheugen
# boeken: [{"id": "...", "title": "...", "author": "...", "image_filename": "...", "review": "...", "comments": [...]}]
books = []

@app.route("/", methods=["GET", "POST"])
def index():
    search_query = request.args.get("search", "").lower()
    
    if request.method == "POST":
        title = request.form.get("title")
        author = request.form.get("author")
        review = request.form.get("review")
        image = request.files.get("image")

        if not title or not author or not review:
            return "Vul de titel, auteur en recensie in.", 400

        book_id = str(uuid.uuid4())
        image_filename = None
        
        if image and image.filename:
            safe_name = secure_filename(image.filename)
            image_filename = f"{book_id}_{safe_name}"
            image.save(os.path.join(app.config["UPLOAD_FOLDER"], image_filename))

        books.append({
            "id": book_id,
            "title": title,
            "author": author,
            "image_filename": image_filename,
            "review": review,
            "comments": []
        })

        return redirect(url_for("index"))

    filtered_books = books
    if search_query:
        filtered_books = [
            b for b in books 
            if search_query in b["title"].lower() or search_query in b["author"].lower() or search_query in b["review"].lower()
        ]

    return render_template("index.html", books=filtered_books, search_query=search_query)

@app.route("/comment/<book_id>", methods=["POST"])
def add_comment(book_id):
    comment_text = request.form.get("comment")
    if comment_text:
        for book in books:
            if book["id"] == book_id:
                book["comments"].append(comment_text)
                break
    return redirect(url_for("index"))

@app.route("/uploads/<filename>")
def uploaded_file(filename):
    return send_from_directory(app.config["UPLOAD_FOLDER"], filename)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
